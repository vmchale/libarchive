# libarchive

[![Hackage CI](https://matrix.hackage.haskell.org/api/v2/packages/libarchive/badge)](https://matrix.hackage.haskell.org/package/libarchive)
[![Hackage](https://img.shields.io/hackage/v/libarchive.svg)](http://hackage.haskell.org/package/libarchive)
[![Dependencies of latest version on Hackage](https://img.shields.io/hackage-deps/v/libarchive.svg)](https://hackage.haskell.org/package/libarchive)

This contains partial Haskell bindings around
[libarchive](http://libarchive.org/). It was created as an alternative to
[tar](http://hackage.haskell.org/package/tar), but it supports more archive
formats.

Right now it only has support for decompressing archives.
